package ir;

public abstract class Instruction {
}
