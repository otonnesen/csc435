package ast;

public abstract class Literal extends Expression {
}
