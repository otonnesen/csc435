// $ANTLR 3.5.2 ./src/ul.g 2020-01-28 16:37:22

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class ulLexer extends Lexer {
	public static final int EOF=-1;
	public static final int BOOLEAN=4;
	public static final int CHAR=5;
	public static final int CHAR_CONST=6;
	public static final int CLOSEBRACE=7;
	public static final int CLOSEBRACKET=8;
	public static final int CLOSEPAREN=9;
	public static final int COMMA=10;
	public static final int COMMENT=11;
	public static final int ELSE=12;
	public static final int EQUALS=13;
	public static final int FALSE=14;
	public static final int FLOAT=15;
	public static final int FLOAT_CONST=16;
	public static final int ID=17;
	public static final int IF=18;
	public static final int INT=19;
	public static final int INT_CONST=20;
	public static final int IS_EQUAL=21;
	public static final int LESS_THAN=22;
	public static final int MINUS=23;
	public static final int OPENBRACE=24;
	public static final int OPENBRACKET=25;
	public static final int OPENPAREN=26;
	public static final int PLUS=27;
	public static final int PRINT=28;
	public static final int PRINTLN=29;
	public static final int RETURN=30;
	public static final int SEMICOLON=31;
	public static final int STRING=32;
	public static final int STRING_CONST=33;
	public static final int TIMES=34;
	public static final int TRUE=35;
	public static final int VOID=36;
	public static final int WHILE=37;
	public static final int WS=38;

	// delegates
	// delegators
	public Lexer[] getDelegates() {
		return new Lexer[] {};
	}

	public ulLexer() {} 
	public ulLexer(CharStream input) {
		this(input, new RecognizerSharedState());
	}
	public ulLexer(CharStream input, RecognizerSharedState state) {
		super(input,state);
	}
	@Override public String getGrammarFileName() { return "./src/ul.g"; }

	// $ANTLR start "INT"
	public final void mINT() throws RecognitionException {
		try {
			int _type = INT;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:353:8: ( 'int' )
			// ./src/ul.g:353:10: 'int'
			{
			match("int"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "INT"

	// $ANTLR start "FLOAT"
	public final void mFLOAT() throws RecognitionException {
		try {
			int _type = FLOAT;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:356:9: ( 'float' )
			// ./src/ul.g:356:11: 'float'
			{
			match("float"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "FLOAT"

	// $ANTLR start "CHAR"
	public final void mCHAR() throws RecognitionException {
		try {
			int _type = CHAR;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:359:8: ( 'char' )
			// ./src/ul.g:359:10: 'char'
			{
			match("char"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "CHAR"

	// $ANTLR start "STRING"
	public final void mSTRING() throws RecognitionException {
		try {
			int _type = STRING;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:362:10: ( 'string' )
			// ./src/ul.g:362:12: 'string'
			{
			match("string"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "STRING"

	// $ANTLR start "BOOLEAN"
	public final void mBOOLEAN() throws RecognitionException {
		try {
			int _type = BOOLEAN;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:365:11: ( 'boolean' )
			// ./src/ul.g:365:13: 'boolean'
			{
			match("boolean"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "BOOLEAN"

	// $ANTLR start "VOID"
	public final void mVOID() throws RecognitionException {
		try {
			int _type = VOID;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:368:8: ( 'void' )
			// ./src/ul.g:368:10: 'void'
			{
			match("void"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "VOID"

	// $ANTLR start "IF"
	public final void mIF() throws RecognitionException {
		try {
			int _type = IF;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:371:7: ( 'if' )
			// ./src/ul.g:371:9: 'if'
			{
			match("if"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "IF"

	// $ANTLR start "ELSE"
	public final void mELSE() throws RecognitionException {
		try {
			int _type = ELSE;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:374:8: ( 'else' )
			// ./src/ul.g:374:10: 'else'
			{
			match("else"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "ELSE"

	// $ANTLR start "WHILE"
	public final void mWHILE() throws RecognitionException {
		try {
			int _type = WHILE;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:377:9: ( 'while' )
			// ./src/ul.g:377:11: 'while'
			{
			match("while"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "WHILE"

	// $ANTLR start "PRINT"
	public final void mPRINT() throws RecognitionException {
		try {
			int _type = PRINT;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:380:9: ( 'print' )
			// ./src/ul.g:380:11: 'print'
			{
			match("print"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "PRINT"

	// $ANTLR start "PRINTLN"
	public final void mPRINTLN() throws RecognitionException {
		try {
			int _type = PRINTLN;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:383:11: ( 'println' )
			// ./src/ul.g:383:13: 'println'
			{
			match("println"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "PRINTLN"

	// $ANTLR start "RETURN"
	public final void mRETURN() throws RecognitionException {
		try {
			int _type = RETURN;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:386:10: ( 'return' )
			// ./src/ul.g:386:12: 'return'
			{
			match("return"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "RETURN"

	// $ANTLR start "TRUE"
	public final void mTRUE() throws RecognitionException {
		try {
			int _type = TRUE;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:389:8: ( 'true' )
			// ./src/ul.g:389:10: 'true'
			{
			match("true"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "TRUE"

	// $ANTLR start "FALSE"
	public final void mFALSE() throws RecognitionException {
		try {
			int _type = FALSE;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:392:9: ( 'false' )
			// ./src/ul.g:392:11: 'false'
			{
			match("false"); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "FALSE"

	// $ANTLR start "IS_EQUAL"
	public final void mIS_EQUAL() throws RecognitionException {
		try {
			int _type = IS_EQUAL;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:395:11: ( '==' )
			// ./src/ul.g:395:13: '=='
			{
			match("=="); 

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "IS_EQUAL"

	// $ANTLR start "LESS_THAN"
	public final void mLESS_THAN() throws RecognitionException {
		try {
			int _type = LESS_THAN;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:398:12: ( '<' )
			// ./src/ul.g:398:14: '<'
			{
			match('<'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "LESS_THAN"

	// $ANTLR start "PLUS"
	public final void mPLUS() throws RecognitionException {
		try {
			int _type = PLUS;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:401:8: ( '+' )
			// ./src/ul.g:401:10: '+'
			{
			match('+'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "PLUS"

	// $ANTLR start "MINUS"
	public final void mMINUS() throws RecognitionException {
		try {
			int _type = MINUS;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:404:9: ( '-' )
			// ./src/ul.g:404:11: '-'
			{
			match('-'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "MINUS"

	// $ANTLR start "TIMES"
	public final void mTIMES() throws RecognitionException {
		try {
			int _type = TIMES;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:407:9: ( '*' )
			// ./src/ul.g:407:11: '*'
			{
			match('*'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "TIMES"

	// $ANTLR start "EQUALS"
	public final void mEQUALS() throws RecognitionException {
		try {
			int _type = EQUALS;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:410:10: ( '=' )
			// ./src/ul.g:410:12: '='
			{
			match('='); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "EQUALS"

	// $ANTLR start "OPENPAREN"
	public final void mOPENPAREN() throws RecognitionException {
		try {
			int _type = OPENPAREN;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:413:12: ( '(' )
			// ./src/ul.g:413:14: '('
			{
			match('('); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "OPENPAREN"

	// $ANTLR start "CLOSEPAREN"
	public final void mCLOSEPAREN() throws RecognitionException {
		try {
			int _type = CLOSEPAREN;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:416:13: ( ')' )
			// ./src/ul.g:416:15: ')'
			{
			match(')'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "CLOSEPAREN"

	// $ANTLR start "OPENBRACE"
	public final void mOPENBRACE() throws RecognitionException {
		try {
			int _type = OPENBRACE;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:419:12: ( '{' )
			// ./src/ul.g:419:14: '{'
			{
			match('{'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "OPENBRACE"

	// $ANTLR start "CLOSEBRACE"
	public final void mCLOSEBRACE() throws RecognitionException {
		try {
			int _type = CLOSEBRACE;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:422:13: ( '}' )
			// ./src/ul.g:422:15: '}'
			{
			match('}'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "CLOSEBRACE"

	// $ANTLR start "OPENBRACKET"
	public final void mOPENBRACKET() throws RecognitionException {
		try {
			int _type = OPENBRACKET;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:425:14: ( '[' )
			// ./src/ul.g:425:16: '['
			{
			match('['); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "OPENBRACKET"

	// $ANTLR start "CLOSEBRACKET"
	public final void mCLOSEBRACKET() throws RecognitionException {
		try {
			int _type = CLOSEBRACKET;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:428:14: ( ']' )
			// ./src/ul.g:428:16: ']'
			{
			match(']'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "CLOSEBRACKET"

	// $ANTLR start "SEMICOLON"
	public final void mSEMICOLON() throws RecognitionException {
		try {
			int _type = SEMICOLON;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:431:12: ( ';' )
			// ./src/ul.g:431:14: ';'
			{
			match(';'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "SEMICOLON"

	// $ANTLR start "COMMA"
	public final void mCOMMA() throws RecognitionException {
		try {
			int _type = COMMA;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:434:9: ( ',' )
			// ./src/ul.g:434:11: ','
			{
			match(','); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "COMMA"

	// $ANTLR start "INT_CONST"
	public final void mINT_CONST() throws RecognitionException {
		try {
			int _type = INT_CONST;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:437:12: ( ( '0' .. '9' )+ )
			// ./src/ul.g:437:14: ( '0' .. '9' )+
			{
			// ./src/ul.g:437:14: ( '0' .. '9' )+
			int cnt1=0;
			loop1:
			while (true) {
				int alt1=2;
				int LA1_0 = input.LA(1);
				if ( ((LA1_0 >= '0' && LA1_0 <= '9')) ) {
					alt1=1;
				}

				switch (alt1) {
				case 1 :
					// ./src/ul.g:
					{
					if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					if ( cnt1 >= 1 ) break loop1;
					EarlyExitException eee = new EarlyExitException(1, input);
					throw eee;
				}
				cnt1++;
			}

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "INT_CONST"

	// $ANTLR start "FLOAT_CONST"
	public final void mFLOAT_CONST() throws RecognitionException {
		try {
			int _type = FLOAT_CONST;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:440:14: ( ( '0' .. '9' )+ '.' ( '0' .. '9' )+ )
			// ./src/ul.g:440:16: ( '0' .. '9' )+ '.' ( '0' .. '9' )+
			{
			// ./src/ul.g:440:16: ( '0' .. '9' )+
			int cnt2=0;
			loop2:
			while (true) {
				int alt2=2;
				int LA2_0 = input.LA(1);
				if ( ((LA2_0 >= '0' && LA2_0 <= '9')) ) {
					alt2=1;
				}

				switch (alt2) {
				case 1 :
					// ./src/ul.g:
					{
					if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					if ( cnt2 >= 1 ) break loop2;
					EarlyExitException eee = new EarlyExitException(2, input);
					throw eee;
				}
				cnt2++;
			}

			match('.'); 
			// ./src/ul.g:440:30: ( '0' .. '9' )+
			int cnt3=0;
			loop3:
			while (true) {
				int alt3=2;
				int LA3_0 = input.LA(1);
				if ( ((LA3_0 >= '0' && LA3_0 <= '9')) ) {
					alt3=1;
				}

				switch (alt3) {
				case 1 :
					// ./src/ul.g:
					{
					if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					if ( cnt3 >= 1 ) break loop3;
					EarlyExitException eee = new EarlyExitException(3, input);
					throw eee;
				}
				cnt3++;
			}

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "FLOAT_CONST"

	// $ANTLR start "CHAR_CONST"
	public final void mCHAR_CONST() throws RecognitionException {
		try {
			int _type = CHAR_CONST;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:443:13: ( '\\'' ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '!' | ',' | '.' | ':' | '_' | '{' | '}' | ' ' ) '\\'' )
			// ./src/ul.g:443:15: '\\'' ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '!' | ',' | '.' | ':' | '_' | '{' | '}' | ' ' ) '\\''
			{
			match('\''); 
			if ( (input.LA(1) >= ' ' && input.LA(1) <= '!')||input.LA(1)==','||input.LA(1)=='.'||(input.LA(1) >= '0' && input.LA(1) <= ':')||(input.LA(1) >= 'A' && input.LA(1) <= 'Z')||input.LA(1)=='_'||(input.LA(1) >= 'a' && input.LA(1) <= '{')||input.LA(1)=='}' ) {
				input.consume();
			}
			else {
				MismatchedSetException mse = new MismatchedSetException(null,input);
				recover(mse);
				throw mse;
			}
			match('\''); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "CHAR_CONST"

	// $ANTLR start "STRING_CONST"
	public final void mSTRING_CONST() throws RecognitionException {
		try {
			int _type = STRING_CONST;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:458:14: ( '\"' ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '!' | ',' | '.' | ':' | '_' | '{' | '}' | ' ' )* '\"' )
			// ./src/ul.g:458:16: '\"' ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '!' | ',' | '.' | ':' | '_' | '{' | '}' | ' ' )* '\"'
			{
			match('\"'); 
			// ./src/ul.g:459:6: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '!' | ',' | '.' | ':' | '_' | '{' | '}' | ' ' )*
			loop4:
			while (true) {
				int alt4=2;
				int LA4_0 = input.LA(1);
				if ( ((LA4_0 >= ' ' && LA4_0 <= '!')||LA4_0==','||LA4_0=='.'||(LA4_0 >= '0' && LA4_0 <= ':')||(LA4_0 >= 'A' && LA4_0 <= 'Z')||LA4_0=='_'||(LA4_0 >= 'a' && LA4_0 <= '{')||LA4_0=='}') ) {
					alt4=1;
				}

				switch (alt4) {
				case 1 :
					// ./src/ul.g:
					{
					if ( (input.LA(1) >= ' ' && input.LA(1) <= '!')||input.LA(1)==','||input.LA(1)=='.'||(input.LA(1) >= '0' && input.LA(1) <= ':')||(input.LA(1) >= 'A' && input.LA(1) <= 'Z')||input.LA(1)=='_'||(input.LA(1) >= 'a' && input.LA(1) <= '{')||input.LA(1)=='}' ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					break loop4;
				}
			}

			match('\"'); 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "STRING_CONST"

	// $ANTLR start "ID"
	public final void mID() throws RecognitionException {
		try {
			int _type = ID;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:473:7: ( ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* )
			// ./src/ul.g:473:9: ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
			{
			if ( (input.LA(1) >= 'A' && input.LA(1) <= 'Z')||input.LA(1)=='_'||(input.LA(1) >= 'a' && input.LA(1) <= 'z') ) {
				input.consume();
			}
			else {
				MismatchedSetException mse = new MismatchedSetException(null,input);
				recover(mse);
				throw mse;
			}
			// ./src/ul.g:473:32: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
			loop5:
			while (true) {
				int alt5=2;
				int LA5_0 = input.LA(1);
				if ( ((LA5_0 >= '0' && LA5_0 <= '9')||(LA5_0 >= 'A' && LA5_0 <= 'Z')||LA5_0=='_'||(LA5_0 >= 'a' && LA5_0 <= 'z')) ) {
					alt5=1;
				}

				switch (alt5) {
				case 1 :
					// ./src/ul.g:
					{
					if ( (input.LA(1) >= '0' && input.LA(1) <= '9')||(input.LA(1) >= 'A' && input.LA(1) <= 'Z')||input.LA(1)=='_'||(input.LA(1) >= 'a' && input.LA(1) <= 'z') ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					break loop5;
				}
			}

			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "ID"

	// $ANTLR start "WS"
	public final void mWS() throws RecognitionException {
		try {
			int _type = WS;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:476:7: ( ( ' ' | '\\n' | '\\t' )+ )
			// ./src/ul.g:476:9: ( ' ' | '\\n' | '\\t' )+
			{
			// ./src/ul.g:476:9: ( ' ' | '\\n' | '\\t' )+
			int cnt6=0;
			loop6:
			while (true) {
				int alt6=2;
				int LA6_0 = input.LA(1);
				if ( ((LA6_0 >= '\t' && LA6_0 <= '\n')||LA6_0==' ') ) {
					alt6=1;
				}

				switch (alt6) {
				case 1 :
					// ./src/ul.g:
					{
					if ( (input.LA(1) >= '\t' && input.LA(1) <= '\n')||input.LA(1)==' ' ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					if ( cnt6 >= 1 ) break loop6;
					EarlyExitException eee = new EarlyExitException(6, input);
					throw eee;
				}
				cnt6++;
			}

			 _channel = HIDDEN; 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "WS"

	// $ANTLR start "COMMENT"
	public final void mCOMMENT() throws RecognitionException {
		try {
			int _type = COMMENT;
			int _channel = DEFAULT_TOKEN_CHANNEL;
			// ./src/ul.g:479:11: ( '//' (~ '\\n' )* '\\n' )
			// ./src/ul.g:479:13: '//' (~ '\\n' )* '\\n'
			{
			match("//"); 

			// ./src/ul.g:479:18: (~ '\\n' )*
			loop7:
			while (true) {
				int alt7=2;
				int LA7_0 = input.LA(1);
				if ( ((LA7_0 >= '\u0000' && LA7_0 <= '\t')||(LA7_0 >= '\u000B' && LA7_0 <= '\uFFFF')) ) {
					alt7=1;
				}

				switch (alt7) {
				case 1 :
					// ./src/ul.g:
					{
					if ( (input.LA(1) >= '\u0000' && input.LA(1) <= '\t')||(input.LA(1) >= '\u000B' && input.LA(1) <= '\uFFFF') ) {
						input.consume();
					}
					else {
						MismatchedSetException mse = new MismatchedSetException(null,input);
						recover(mse);
						throw mse;
					}
					}
					break;

				default :
					break loop7;
				}
			}

			match('\n'); 
			 _channel = HIDDEN; 
			}

			state.type = _type;
			state.channel = _channel;
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "COMMENT"

	@Override
	public void mTokens() throws RecognitionException {
		// ./src/ul.g:1:8: ( INT | FLOAT | CHAR | STRING | BOOLEAN | VOID | IF | ELSE | WHILE | PRINT | PRINTLN | RETURN | TRUE | FALSE | IS_EQUAL | LESS_THAN | PLUS | MINUS | TIMES | EQUALS | OPENPAREN | CLOSEPAREN | OPENBRACE | CLOSEBRACE | OPENBRACKET | CLOSEBRACKET | SEMICOLON | COMMA | INT_CONST | FLOAT_CONST | CHAR_CONST | STRING_CONST | ID | WS | COMMENT )
		int alt8=35;
		alt8 = dfa8.predict(input);
		switch (alt8) {
			case 1 :
				// ./src/ul.g:1:10: INT
				{
				mINT(); 

				}
				break;
			case 2 :
				// ./src/ul.g:1:14: FLOAT
				{
				mFLOAT(); 

				}
				break;
			case 3 :
				// ./src/ul.g:1:20: CHAR
				{
				mCHAR(); 

				}
				break;
			case 4 :
				// ./src/ul.g:1:25: STRING
				{
				mSTRING(); 

				}
				break;
			case 5 :
				// ./src/ul.g:1:32: BOOLEAN
				{
				mBOOLEAN(); 

				}
				break;
			case 6 :
				// ./src/ul.g:1:40: VOID
				{
				mVOID(); 

				}
				break;
			case 7 :
				// ./src/ul.g:1:45: IF
				{
				mIF(); 

				}
				break;
			case 8 :
				// ./src/ul.g:1:48: ELSE
				{
				mELSE(); 

				}
				break;
			case 9 :
				// ./src/ul.g:1:53: WHILE
				{
				mWHILE(); 

				}
				break;
			case 10 :
				// ./src/ul.g:1:59: PRINT
				{
				mPRINT(); 

				}
				break;
			case 11 :
				// ./src/ul.g:1:65: PRINTLN
				{
				mPRINTLN(); 

				}
				break;
			case 12 :
				// ./src/ul.g:1:73: RETURN
				{
				mRETURN(); 

				}
				break;
			case 13 :
				// ./src/ul.g:1:80: TRUE
				{
				mTRUE(); 

				}
				break;
			case 14 :
				// ./src/ul.g:1:85: FALSE
				{
				mFALSE(); 

				}
				break;
			case 15 :
				// ./src/ul.g:1:91: IS_EQUAL
				{
				mIS_EQUAL(); 

				}
				break;
			case 16 :
				// ./src/ul.g:1:100: LESS_THAN
				{
				mLESS_THAN(); 

				}
				break;
			case 17 :
				// ./src/ul.g:1:110: PLUS
				{
				mPLUS(); 

				}
				break;
			case 18 :
				// ./src/ul.g:1:115: MINUS
				{
				mMINUS(); 

				}
				break;
			case 19 :
				// ./src/ul.g:1:121: TIMES
				{
				mTIMES(); 

				}
				break;
			case 20 :
				// ./src/ul.g:1:127: EQUALS
				{
				mEQUALS(); 

				}
				break;
			case 21 :
				// ./src/ul.g:1:134: OPENPAREN
				{
				mOPENPAREN(); 

				}
				break;
			case 22 :
				// ./src/ul.g:1:144: CLOSEPAREN
				{
				mCLOSEPAREN(); 

				}
				break;
			case 23 :
				// ./src/ul.g:1:155: OPENBRACE
				{
				mOPENBRACE(); 

				}
				break;
			case 24 :
				// ./src/ul.g:1:165: CLOSEBRACE
				{
				mCLOSEBRACE(); 

				}
				break;
			case 25 :
				// ./src/ul.g:1:176: OPENBRACKET
				{
				mOPENBRACKET(); 

				}
				break;
			case 26 :
				// ./src/ul.g:1:188: CLOSEBRACKET
				{
				mCLOSEBRACKET(); 

				}
				break;
			case 27 :
				// ./src/ul.g:1:201: SEMICOLON
				{
				mSEMICOLON(); 

				}
				break;
			case 28 :
				// ./src/ul.g:1:211: COMMA
				{
				mCOMMA(); 

				}
				break;
			case 29 :
				// ./src/ul.g:1:217: INT_CONST
				{
				mINT_CONST(); 

				}
				break;
			case 30 :
				// ./src/ul.g:1:227: FLOAT_CONST
				{
				mFLOAT_CONST(); 

				}
				break;
			case 31 :
				// ./src/ul.g:1:239: CHAR_CONST
				{
				mCHAR_CONST(); 

				}
				break;
			case 32 :
				// ./src/ul.g:1:250: STRING_CONST
				{
				mSTRING_CONST(); 

				}
				break;
			case 33 :
				// ./src/ul.g:1:263: ID
				{
				mID(); 

				}
				break;
			case 34 :
				// ./src/ul.g:1:266: WS
				{
				mWS(); 

				}
				break;
			case 35 :
				// ./src/ul.g:1:269: COMMENT
				{
				mCOMMENT(); 

				}
				break;

		}
	}


	protected DFA8 dfa8 = new DFA8(this);
	static final String DFA8_eotS =
		"\1\uffff\13\34\1\55\14\uffff\1\56\5\uffff\1\34\1\61\13\34\4\uffff\1\75"+
		"\1\uffff\13\34\1\uffff\2\34\1\113\2\34\1\116\1\117\3\34\1\123\1\124\1"+
		"\125\1\uffff\2\34\2\uffff\1\130\1\132\1\34\3\uffff\1\134\1\34\1\uffff"+
		"\1\34\1\uffff\1\137\1\uffff\1\140\1\141\3\uffff";
	static final String DFA8_eofS =
		"\142\uffff";
	static final String DFA8_minS =
		"\1\11\1\146\1\141\1\150\1\164\2\157\1\154\1\150\1\162\1\145\1\162\1\75"+
		"\14\uffff\1\56\5\uffff\1\164\1\60\1\157\1\154\1\141\1\162\1\157\1\151"+
		"\1\163\2\151\1\164\1\165\4\uffff\1\60\1\uffff\1\141\1\163\1\162\1\151"+
		"\1\154\1\144\1\145\1\154\1\156\1\165\1\145\1\uffff\1\164\1\145\1\60\1"+
		"\156\1\145\2\60\1\145\1\164\1\162\3\60\1\uffff\1\147\1\141\2\uffff\2\60"+
		"\1\156\3\uffff\1\60\1\156\1\uffff\1\156\1\uffff\1\60\1\uffff\2\60\3\uffff";
	static final String DFA8_maxS =
		"\1\175\1\156\1\154\1\150\1\164\2\157\1\154\1\150\1\162\1\145\1\162\1\75"+
		"\14\uffff\1\71\5\uffff\1\164\1\172\1\157\1\154\1\141\1\162\1\157\1\151"+
		"\1\163\2\151\1\164\1\165\4\uffff\1\172\1\uffff\1\141\1\163\1\162\1\151"+
		"\1\154\1\144\1\145\1\154\1\156\1\165\1\145\1\uffff\1\164\1\145\1\172\1"+
		"\156\1\145\2\172\1\145\1\164\1\162\3\172\1\uffff\1\147\1\141\2\uffff\2"+
		"\172\1\156\3\uffff\1\172\1\156\1\uffff\1\156\1\uffff\1\172\1\uffff\2\172"+
		"\3\uffff";
	static final String DFA8_acceptS =
		"\15\uffff\1\20\1\21\1\22\1\23\1\25\1\26\1\27\1\30\1\31\1\32\1\33\1\34"+
		"\1\uffff\1\37\1\40\1\41\1\42\1\43\15\uffff\1\17\1\24\1\35\1\36\1\uffff"+
		"\1\7\13\uffff\1\1\15\uffff\1\3\2\uffff\1\6\1\10\3\uffff\1\15\1\2\1\16"+
		"\2\uffff\1\11\1\uffff\1\12\1\uffff\1\4\2\uffff\1\14\1\5\1\13";
	static final String DFA8_specialS =
		"\142\uffff}>";
	static final String[] DFA8_transitionS = {
			"\2\35\25\uffff\1\35\1\uffff\1\33\4\uffff\1\32\1\21\1\22\1\20\1\16\1\30"+
			"\1\17\1\uffff\1\36\12\31\1\uffff\1\27\1\15\1\14\3\uffff\32\34\1\25\1"+
			"\uffff\1\26\1\uffff\1\34\1\uffff\1\34\1\5\1\3\1\34\1\7\1\2\2\34\1\1\6"+
			"\34\1\11\1\34\1\12\1\4\1\13\1\34\1\6\1\10\3\34\1\23\1\uffff\1\24",
			"\1\40\7\uffff\1\37",
			"\1\42\12\uffff\1\41",
			"\1\43",
			"\1\44",
			"\1\45",
			"\1\46",
			"\1\47",
			"\1\50",
			"\1\51",
			"\1\52",
			"\1\53",
			"\1\54",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"\1\57\1\uffff\12\31",
			"",
			"",
			"",
			"",
			"",
			"\1\60",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"\1\62",
			"\1\63",
			"\1\64",
			"\1\65",
			"\1\66",
			"\1\67",
			"\1\70",
			"\1\71",
			"\1\72",
			"\1\73",
			"\1\74",
			"",
			"",
			"",
			"",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"",
			"\1\76",
			"\1\77",
			"\1\100",
			"\1\101",
			"\1\102",
			"\1\103",
			"\1\104",
			"\1\105",
			"\1\106",
			"\1\107",
			"\1\110",
			"",
			"\1\111",
			"\1\112",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"\1\114",
			"\1\115",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"\1\120",
			"\1\121",
			"\1\122",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"",
			"\1\126",
			"\1\127",
			"",
			"",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\13\34\1\131\16\34",
			"\1\133",
			"",
			"",
			"",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"\1\135",
			"",
			"\1\136",
			"",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
			"",
			"",
			""
	};

	static final short[] DFA8_eot = DFA.unpackEncodedString(DFA8_eotS);
	static final short[] DFA8_eof = DFA.unpackEncodedString(DFA8_eofS);
	static final char[] DFA8_min = DFA.unpackEncodedStringToUnsignedChars(DFA8_minS);
	static final char[] DFA8_max = DFA.unpackEncodedStringToUnsignedChars(DFA8_maxS);
	static final short[] DFA8_accept = DFA.unpackEncodedString(DFA8_acceptS);
	static final short[] DFA8_special = DFA.unpackEncodedString(DFA8_specialS);
	static final short[][] DFA8_transition;

	static {
		int numStates = DFA8_transitionS.length;
		DFA8_transition = new short[numStates][];
		for (int i=0; i<numStates; i++) {
			DFA8_transition[i] = DFA.unpackEncodedString(DFA8_transitionS[i]);
		}
	}

	protected class DFA8 extends DFA {

		public DFA8(BaseRecognizer recognizer) {
			this.recognizer = recognizer;
			this.decisionNumber = 8;
			this.eot = DFA8_eot;
			this.eof = DFA8_eof;
			this.min = DFA8_min;
			this.max = DFA8_max;
			this.accept = DFA8_accept;
			this.special = DFA8_special;
			this.transition = DFA8_transition;
		}
		@Override
		public String getDescription() {
			return "1:1: Tokens : ( INT | FLOAT | CHAR | STRING | BOOLEAN | VOID | IF | ELSE | WHILE | PRINT | PRINTLN | RETURN | TRUE | FALSE | IS_EQUAL | LESS_THAN | PLUS | MINUS | TIMES | EQUALS | OPENPAREN | CLOSEPAREN | OPENBRACE | CLOSEBRACE | OPENBRACKET | CLOSEBRACKET | SEMICOLON | COMMA | INT_CONST | FLOAT_CONST | CHAR_CONST | STRING_CONST | ID | WS | COMMENT );";
		}
	}

}
