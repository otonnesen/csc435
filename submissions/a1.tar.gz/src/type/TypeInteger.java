package type;

public class TypeInteger extends Type {
	private String name;

	public TypeInteger() {
		this.name = "int";
	}

	public String getName() {
		return this.name;
	}
}
