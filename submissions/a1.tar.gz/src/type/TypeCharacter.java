package type;

public class TypeCharacter extends Type {
	private String name;

	public TypeCharacter() {
		this.name = "char";
	}

	public String getName() {
		return this.name;
	}
}
