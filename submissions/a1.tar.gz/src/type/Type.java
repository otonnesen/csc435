package type;

public abstract class Type {
	private String name;

	public abstract String getName();
}
