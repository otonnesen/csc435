package type;

public class TypeVoid extends Type {
	private String name;

	public TypeVoid() {
		this.name = "void";
	}

	public String getName() {
		return this.name;
	}
}
