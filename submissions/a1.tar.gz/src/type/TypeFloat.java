package type;

public class TypeFloat extends Type {
	private String name;

	public TypeFloat() {
		this.name = "float";
	}

	public String getName() {
		return this.name;
	}
}
