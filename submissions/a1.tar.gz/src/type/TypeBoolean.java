package type;

public class TypeBoolean extends Type {
	private String name;

	public TypeBoolean() {
		this.name = "boolean";
	}

	public String getName() {
		return this.name;
	}
}
